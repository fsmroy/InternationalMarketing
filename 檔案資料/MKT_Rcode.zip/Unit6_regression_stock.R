library(lubridate)
stock <- read.csv("Asia_index.csv", header=TRUE)
stock$Date<-as.Date(stock$Date)
tr_id<-sum(ymd(stock$Date)<="2022-12-31") #end of training

stock <- stock[,c(2:15)] #remove 1st column Date
stock.tr<-stock[1:tr_id,] #training
stock.ts<-stock[-c(1:tr_id),] #testing

#####stock price forecasting 
table1 = array(0, c(3,3)) #training
rownames(table1)<-c("RMSE","MAE","MAPE")
colnames(table1)<-c("MLR","MARS","KNN")

table2 = array(0, c(3,3)) #testing
rownames(table2)<-c("RMSE","MAE","MAPE")
colnames(table2)<-c("MLR","MARS","KNN")

##############################
mlr.stock<- lm(Taiwan~., stock.tr) #all features
summary(mlr.stock)
pred.mlr<-predict.lm(mlr.stock, stock.ts[,-14])

table1[1,1] <-sqrt(mean((stock.tr$Taiwan - mlr.stock$fitted.values)^2))
table1[2,1] <-mean(abs(stock.tr$Taiwan - mlr.stock$fitted.values))
table1[3,1] <-mean(abs((stock.tr$Taiwan - mlr.stock$fitted.values)/stock.tr$Taiwan))

table2[1,1] <-sqrt(mean((stock.ts$Taiwan - pred.mlr)^2))
table2[2,1] <-mean(abs(stock.ts$Taiwan - pred.mlr))
table2[3,1] <-mean(abs((stock.ts$Taiwan - pred.mlr)/stock.ts$Taiwan))

#####################################################################
#install.packages("earth")
library(earth)
mars.stock<-earth(Taiwan~., degree=3, trace=2, stock.tr) #degree?Ҽ{?椬??
evimp(mars.stock, trim=FALSE)
pred.mars<-predict(mars.stock, stock.ts[,-14])

table1[1,2] <-sqrt(mean((stock.tr$Taiwan - mars.stock$fitted.values)^2))
table1[2,2] <-mean(abs(stock.tr$Taiwan - mars.stock$fitted.values))
table1[3,2] <-mean(abs((stock.tr$Taiwan - mars.stock$fitted.values)/stock.tr$Taiwan))

table2[1,2] <-sqrt(mean((stock.ts$Taiwan - pred.mars)^2))
table2[2,2] <-mean(abs(stock.ts$Taiwan - pred.mars))
table2[3,2] <-mean(abs((stock.ts$Taiwan - pred.mars)/stock.ts$Taiwan))

#############KNN########
#install.packages("FNN")
library(FNN)
knn.stock.tr<- knn.reg(stock.tr[,-14], stock.tr[,-14], stock.tr[,14], k=2, algorithm= "brute")
knn.stock.ts<- knn.reg(stock.tr[,-14], stock.ts[,-14], stock.tr[,14], k=2, algorithm= "brute")

table1[1,3] <-sqrt(mean((stock.tr$Taiwan - knn.stock.tr$pred)^2))
table1[2,3] <-mean(abs(stock.tr$Taiwan - knn.stock.tr$pred))
table1[3,3] <-mean(abs((stock.tr$Taiwan - knn.stock.tr$pred)/stock.tr$Taiwan))

table2[1,3] <-sqrt(mean((stock.ts$Taiwan - knn.stock.ts$pred)^2))
table2[2,3] <-mean(abs(stock.ts$Taiwan - knn.stock.ts$pred))
table2[3,3] <-mean(abs((stock.ts$Taiwan - knn.stock.ts$pred)/stock.ts$Taiwan))

table1 #training
table2 #testing

######visualization
plot(stock.tr$Taiwan, col="black", type='l', ylab="stock", xlab="date", main="Training")
points(mlr.stock$fitted.values,col="red", pch=1)
points(mars.stock$fitted.values,col="green", pch=2)
points(knn.stock.tr$pred, col="blue", pch=3)

plot(stock.ts$Taiwan, col="black", type='l', ylab="stock", xlab="date", main="Testing")
points(pred.mlr,col="red", pch=1)
points(pred.mars,col="green", pch=2)
points(knn.stock.ts$pred, col="blue", pch=3)
