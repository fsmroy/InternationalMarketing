####### Feature selection for Telecom_churn
table1 = array(0, c(3,3))
rownames(table1)<-c("Recall","Precision","Fmeasure")
colnames(table1)<-c("NB","LR","KNN")

##x1: time spent on long-distance call per month, x2: international calls, x3: local calls, x4: number of dropped calls, x5: payment method for the bill, x6: tariff for local calls, x7: tariff for long-distance calls, x8: age, x9: gender, x10: martial status, x11: # of children, x12: income, x13: car owner, x14: churn labels// Current (not churned), Vol: valuable churner, InVol: leavers (don??t care)
churn_data<-read.table("churn.txt", header=T, sep=",",stringsAsFactors = TRUE)
churn_data<-churn_data[,-1] #remove customer ID
summary(churn_data)

churn_data[,14]<-as.character(churn_data[,14])
churn_data[which(churn_data[,14]!= "Current"), 14]<-"yes"
churn_data[which(churn_data$CHURNED == "Current"), 14]<-"no"
churn_data[,14]<-as.factor(churn_data[,"CHURNED"])

chisq.test(table(churn_data$PAY_MTHD, churn_data$CHURNED)) ##c5
chisq.test(table(churn_data$LocalBillType, churn_data$CHURNED)) ##c6
chisq.test(table(churn_data$LongDistanceBillType, churn_data$CHURNED)) ##c7
chisq.test(table(churn_data$SEX, churn_data$CHURNED)) ##c9
chisq.test(table(churn_data$STATUS, churn_data$CHURNED)) ##c10
chisq.test(table(churn_data$Car_Owner, churn_data$CHURNED)) ##c13

switching=subset(churn_data, CHURNED=="yes")
loyal=subset(churn_data, CHURNED=="no")
t.test(switching$LONGDIST, loyal$LONGDIST, var.equal=FALSE) ##c1
t.test(switching$International, loyal$International, var.equal=FALSE) ##c2
t.test(switching$LOCAL, loyal$LOCAL, var.equal=FALSE) ##c3
t.test(switching$DROPPED, loyal$DROPPED, var.equal=FALSE) ##c4
t.test(switching$AGE, loyal$AGE, var.equal=FALSE) ##c8
t.test(switching$CHILDREN, loyal$CHILDREN, var.equal=FALSE) ##c11
t.test(switching$Est_Income, loyal$Est_Income, var.equal=FALSE) ##c12
churn<-churn_data[,-c(4,5,6,7,10,11,13)]

###################################################################
churn.id<-sample(1: nrow(churn), round(0.3*nrow(churn)) ) 
tr.churn<- churn[-churn.id,] #training
ts.churn<- churn[churn.id,] #testing

#######Naive Bayes
library(MASS)
library(klaR)

NB.churn=NaiveBayes(CHURNED ~ ., data= tr.churn)
names(NB.churn)
NB.churn$apriori
NB.churn$tables

pre_bayes=predict(NB.churn, ts.churn[,-7])
pre_bayes
NB.tab<-table(ts.churn$CHURNED, pre_bayes$class)
NB.tab
sum( as.numeric(pre_bayes$class == ts.churn$CHURNED) )/ nrow(ts.churn)
sum(diag(NB.tab))/sum(NB.tab) #predictive accuracy
table1[1,1]<-NB.tab[2,2]/sum(NB.tab[2,]) #recall
table1[2,1]<-NB.tab[2,2]/sum(NB.tab[,2]) #precision
table1[3,1]<-2*table1[1,1]*table1[2,1]/(table1[1,1]+table1[2,1]) #F measure
table1

########LR
LR.churn<-glm(formula=CHURNED~., family=binomial(link="logit"), data=tr.churn)
summary(LR.churn) #what??s the reason for insignificance

pre.LR=predict.glm(LR.churn, type="response", newdata=ts.churn)
result<-ifelse (round(pre.LR)>=0.5, "yes", "no")
LR.tab=table(ts.churn$CHURNED, result)
LR.tab
sum(diag(LR.tab))/sum(LR.tab) #overall accuracy
table1[1,2]<-LR.tab[2,2]/sum(LR.tab[2,]) #recall
table1[2,2]<-LR.tab[2,2]/sum(LR.tab[,2]) #precision
table1[3,2]<-2*table1[1,2]*table1[2,2]/(table1[1,2]+table1[2,2]) #F measure
table1

#####################################################################
#install.packages("class")
#install.packages("e1071")
library(class)
library(e1071)

tr.churn[,5]<-as.character(tr.churn$SEX)
tr.churn[which(tr.churn[,5]=="F"), 5]<-0  #rename female by 0
tr.churn[which(tr.churn[,5]=="M"), 5]<-1  #rename male by 1
tr.churn[,5]=as.numeric(tr.churn$SEX)
knn.churn.tr<- knn(tr.churn[,-7], tr.churn[,-7], cl=tr.churn[,7], k = 3)
table(tr.churn$CHURNED, knn.churn.tr) #training
sum( as.numeric(tr.churn$CHURNED == knn.churn.tr) )/ nrow(tr.churn)

ts.churn[,5]<-as.character(ts.churn$SEX)
ts.churn[which(ts.churn[,5]=="F"), 5]<-0  #rename female by 0
ts.churn[which(ts.churn[,5]=="M"), 5]<-1  #rename male by 1
ts.churn[,5]=as.numeric(ts.churn$SEX)
knn.churn.ts<- knn(tr.churn[,-7], ts.churn[,-7], cl=tr.churn[,7], k = 3)
KNN.tab<-table(ts.churn$CHURNED, knn.churn.ts) #testing
KNN.tab
sum( diag(KNN.tab) )/ sum(KNN.tab)

table1[1,3]<-KNN.tab[2,2]/sum(KNN.tab[2,]) #recall
table1[2,3]<-KNN.tab[2,2]/sum(KNN.tab[,2]) #precision
table1[3,3]<-2*table1[1,3]*table1[2,3]/(table1[1,3]+table1[2,3]) #F measure

table1

summary(churn)
X=data.frame(LONGDIST=13.683,International=0,LOCAL=35.0144,AGE=58,SEX="F",Est_Income=50290.7)
predict(NB.churn, X)
predict.glm(LR.churn, type="response", newdata=X)
