#stock <- read.table("2016stock.csv", header=T, sep=",")
stock<- read.table("2001_2025stock.csv", header=T, sep=",")
stock$Date<-as.Date(stock$Date)
x=1:nrow(stock); y=as.numeric(stock$Index) #original data
plot(x,y)

#####SMA- simple moving average (???ʥ????k)
table1 = array(0,c(3,3))
rownames(table1)<-c("RMSE","MAE","MAPE")
colnames(table1)<-c("n=5","n=10", "n=20")

##################SMA- simple moving average#########
n=c(5,10,20) #length (n=5, n=10, n=20 moving average)
y1=cbind(y,y,y) #SMA

for (nd in 1:length(n)) #nd: index for length of moving average
{
  for (i in (n[nd]+1) : length(y))
  { 
    j= i-n[nd]; k=i-1;
    y1[i, nd] = mean(y[j : k])
  }
}

table1[1,1:3]<- sqrt(colMeans( (cbind(y,y,y)-y1)^2) ) #RMSE
table1[2,1:3]<- colMeans(abs(cbind(y,y,y)-y1)) #MAE
table1[3,1:3]<- colMeans(abs(cbind(y,y,y)-y1)/y) #MAPE
table1

plot(y, col=1, ylab="stock", xlab="date", main="Simple Moving Average")
points(y1[,1], col="red", pch=2)
points(y1[,2], col="green", pch=3)
points(y1[,3], col="blue", pch=4)

#####EWMA- exponentially weighted moving average (???ƥ??ƪk)
table2 = array(0,c(3,3))
rownames(table2)<-c("RMSE","MAE","MAPE")
colnames(table2)<-c("0.15","0.35", "0.5")

alpha=c(0.15, 0.25, 0.35) #smoothing constant
y2=cbind(y,y,y) #???l??EWMA

for (ld in 1 : length(alpha) )
{ 
  lambda=alpha[ld]
  for (i in 2 : length(y))
  {
    y2[i, ld]= lambda*y[i-1] + (1-lambda)*y2[i-1, ld]
  }
}

table2[1,1:3]<- sqrt(colMeans( (cbind(y,y,y)-y2)^2) ) #RMSE
table2[2,1:3]<- colMeans(abs(cbind(y,y,y)-y2)) #MAE
table2[3,1:3]<- colMeans(abs(cbind(y,y,y)-y2)/y) #MAPE
table2

plot(y, col=1, ylab="stock", xlab="date", main="Exponentially Weighted Moving Average")
points(y2[,1], col="red", pch=2)
points(y2[,2], col="green", pch=3)
points(y2[,3], col="blue", pch=4)

#####################################################################
#install.packages("tseries")
library(tseries)
TS <- ts(y,start=c(2001,1,4), freq=246)

fity11 <- HoltWinters(TS, seasonal="additive")
fity12 <- HoltWinters(TS, seasonal="multiplicative")
fity13 <- HoltWinters(TS, beta = FALSE) #without trend
fity14 <- HoltWinters(TS, gamma = FALSE) #non-seasonal

plot(TS, type="l",lty=1,col="black",ylab="stock",xlab="day")  
lines(fity11$fitted[,1],type="l",lty=1,col="red")
lines(fity12$fitted[,1],type="l",lty=1,col="green")
lines(fity13$fitted[,1],type="l",lty=1,col="blue")
lines(fity14$fitted[,1],type="l",lty=1,col="orange")
title("Forecasts for stock")
#legend("topleft",legend=c("Actual","H-W additive","H-W multiplicative", "Without trend", "Non-seasonal"),fill=c("black","red","green", "blue", "orange"))

table3 = array(0,c(3,4))
rownames(table3)<-c("RMSE","MAE","MAPE")
colnames(table3)<-c("additive","multiplicative", "without trend", "non-seasonal")

#RMSE
table3[1,1] <- sqrt( mean((TS-fity11$fitted[,1])^2) )
table3[1,2] <- sqrt( mean((TS-fity12$fitted[,1])^2) )
table3[1,3] <- sqrt( mean((TS-fity13$fitted[,1])^2) )
table3[1,4] <- sqrt( mean((TS-fity14$fitted[,1])^2) )

#MAE
table3[2,1] <- mean(abs(TS-fity11$fitted[,1]))
table3[2,2] <- mean(abs(TS-fity12$fitted[,1]))
table3[2,3] <- mean(abs(TS-fity13$fitted[,1]))
table3[2,4] <- mean(abs(TS-fity14$fitted[,1]))

#MAPE
table3[3,1] <- mean(abs((TS-fity11$fitted[,1])/TS))
table3[3,2] <- mean(abs((TS-fity12$fitted[,1])/TS))
table3[3,3] <- mean(abs((TS-fity13$fitted[,1])/TS))
table3[3,4] <- mean(abs((TS-fity14$fitted[,1])/TS))

table3 #error matrix for stock

predict(fity11, n.ahead = 20, prediction.interval = TRUE, level = 0.95)
predict(fity12, n.ahead = 20, prediction.interval = TRUE, level = 0.95)
predict(fity13, n.ahead = 20, prediction.interval = TRUE, level = 0.95)
predict(fity14, n.ahead = 20, prediction.interval = TRUE, level = 0.95)