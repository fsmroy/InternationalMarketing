#####Association rules/Titanic + Groceries???ƶ?
#install.packages("arules")
library(arules)

titanic_data <-read.csv("titanic.csv", header=T, sep=",",stringsAsFactors = TRUE)
titanic<-na.exclude(titanic_data) #remove missing values
attach(titanic)
summary(titanic)

rw<-c(which(age==9999), which(fare==9999))  
#identify the id which has missing values in age or fare
titan<-titanic[-rw, 2:5]
titan$survival<-titanic[-rw, 10] #set survival

titan[which(titan[,1]==0), 1]<-"male"  #rename 0 by male
titan[which(titan[,1]==1), 1]<-"female"  #rename 1 by female
titan[,1]=as.factor(titan$gender)

titan[which(titan[,5]==1), 5]<-"yes"
titan[which(titan[,5]==0), 5]<-"no"
titan[,5]<-as.factor(titan[,"survival"])

summary(titan)

char=0
for (i in 1:nrow(titan))
{
  if (titan[i,2]<20) char[i]="young"
  else if(titan[i,2]<50) char[i]="adult"
  else char[i]="old"
}
titan$age=factor(char)
summary(titan$age)

char=0
for (i in 1:nrow(titan))
{
  if (titan[i,4]<14) char[i]="low"
  else if(titan[i,4]<33) char[i]="medium"
  else char[i]="high"
}
titan$fare=factor(char)
summary(titan$fare)

rule0<- apriori(titan, parameter=list(minlen=2, supp=.1, conf=0.8), appearance=list(rhs=c("survival=no", "survival=yes"), default="lhs"))
sorted0<- sort(rule0, by="lift")
inspect(sorted0)

rule1<- apriori(titan, parameter=list(minlen=3, supp=.05, conf=0.8), appearance=list(rhs=c("survival=yes"), default="lhs"))
sorted1<- sort(rule1, by="confidence")
inspect(sorted1)

rule2<- apriori(titan, parameter=list(minlen=3, supp=.05, conf=0.8), appearance=list(rhs=c("survival=no"), default="lhs"))
sorted2<- sort(rule2, by="support")
inspect(sorted2)

##### (grocery datasets)
data("Groceries")
summary(Groceries)
inspect(Groceries[1:8])
rules0=apriori(Groceries, parameter=list(support=.005, confidence=0.6))
rules0
inspect(rules0)

rule.sup=sort(rules0, by="support")
inspect(rule.sup)

rule.con=sort(rules0, by="confidence")
inspect(rule.con)

rule.lif=sort(rules0, by="lift")
inspect(rule.lif)

rules1=apriori(Groceries, parameter=list (maxlen=2, supp=.0001, conf=.1), appearance=list (rhs="mustard", default="lhs"))
inspect(rules1)

#Output frequent iemsets
items0=apriori(Groceries, parameter= list(minlen=2, maxlen=5, supp=0.01, target="frequent itemsets"), control=list(sort=-1)) #breadth first searching (?????N?X??key)
summary(items0)
inspect(items0[1:10])

items=eclat(Groceries, parameter=list (minlen=2, maxlen=5, supp=0.02, target="frequent itemsets")) #depth first searching (?ӫ~?N?X??key)
summary(items)
inspect(items)

rules <- ruleInduction(items, Groceries, conf = .4)
inspect(rules)

#Visualization
#install.packages("MASS")
#install.packages("arulesViz")
library(MASS)
library(arulesViz)

rules2=apriori(Groceries, parameter=list(support=0.0045, confidence=0.6))
plot(rules2)
plot(rules2, measure=c("support", "lift"), shading="confidence")
plot(rules2, method="grouped",control= list(k=10))
plot(rules2, 'interactive'=TRUE)

#####association rule (Indiana Pima diabetes dataset)
Pima.all=read.csv("Pima.csv", header=T, sep=",")
Pima.all[which(Pima.all[,9]==0), 9]<-"no"  
Pima.all[which(Pima.all[,9]==1), 9]<-"yes"  
Pima.all[,9]=as.factor(Pima.all$Outcome)
summary(Pima.all)

Pima=Pima.all #discrete dataset
level_name={}
#number of pregnancy(?h??????)?Bglucose (???}?@??)?Bblood pressure (??��)?Bskin thickness (??��?p??)?BInsulin (?خq??)?BBMI (??????)?Bgene index (?a?ڰ??])?Bage (?~??)

for(i in 1:8)
{
  Pima[, i]=cut(Pima[, i], breaks= 2, ordered_result= T, include.lowest = T)
  level_name<-rbind(level_name, levels(Pima[,i]))
}  #partition attributes into two discrete levels (discretization)

summary(Pima)

#####################################################################
rule3<- apriori(Pima, parameter=list(minlen=3, maxlen=5, supp=.05, conf=0.6), appearance=list(rhs=c("Outcome=yes"), default="lhs"))
sorted3<- sort(rule3, by="lift")
inspect(sorted3)

lhs_yes <- unique(unlist(lhs(sorted3)))
lhs_yes_items <- as(lhs_yes, "list")
lhs_yes_flat <- unlist(lhs_yes_items)
table_yes <- sort(table(lhs_yes_flat), decreasing = TRUE)
cat("🔍 LHS 出現頻率（y=yes）:\n")
print(table_yes)

rule4<- apriori(Pima, parameter=list(minlen=3, maxlen=5, supp=.2, conf=0.8), appearance=list(rhs=c("Outcome=no"), default="lhs"))
sorted4<- sort(rule4, by="support")
inspect(sorted4)

lhs_no <- unique(unlist(lhs(sorted4)))
lhs_no_items <- as(lhs_no, "list")
lhs_no_flat <- unlist(lhs_no_items)
table_no <- sort(table(lhs_no_flat), decreasing = TRUE)
cat("🔍 LHS 出現頻率（y=no）:\n")
print(table_no)