############################
###multi-dimensional scaling
############################
library(stats)
library(ggplot2)

car.data<- read.csv("car_brand.csv", header=T, sep=",")
car<- car.data[,1:11]
## Min=1 MAX=5
##A1~A10: meaning?

###?ҫ??y?Z??//?ڦ??Z??
#dis_car = dist(car[,2:11],'manhattan')
dis_car = dist(car[,2:11],'euclidean')
mds_car = cmdscale(dis_car)
mds_car = data.frame(mds_car)
xy = cbind(mds_car, car$Brand)
names(xy)[3] <- "Brand"
ggplot(xy, aes(x=X1,y=X2,colour=factor(Brand)))+geom_point()

#########################################################
car.mds<- cmdscale(dis_car, k=3, eig=T)
sum((car.mds$eig[1:2])^2)/sum((car.mds$eig)^2)
carx = car.mds$points[,1]
cary = car.mds$points[,2]
plot(carx, cary, pch=1:10, col=1:10, xlab= "1st dim", ylab= "2nd dim", main="Metric_MDS")
text(carx, cary, labels = car$Brand)

#########################################################
#####correspondence analysis for cameras
#image sensor, wide angle, optical zoom, high-speed shutter, big aperture,water proof
#dust proof, digital compass, GPS, wifi, touch panel, electronic view
library(MASS)
camera.data <- read.csv("camera.csv", sep = ",", header = T)
camera.data <- camera.data[,-1]
rownames(camera.data)= c("A1","A2","A3","A4","A5","A6","A7","A8","A9","A10","A11","A12")
camera.ca <- corresp(camera.data, nf = 2)
biplot(camera.ca)

#####correspondence analysis for annual incomes
#install.packages("ca")
library(ca)
brand=data.frame(low=c(28,29,34,44,5), medium=c(7,35,25,28,12), high=c(26,13,6,25,16))
rownames(brand)=c("Starbucks","Louisa","85C","Dante","HWC")
options(digits=3)
brand.ca=ca(brand)
brand.ca #?T?ؤ??P?ұo???~?P?ʶR?????n
names(brand.ca)
plot(brand.ca)

#####Miple correspondence analysis)
##quanti.sup(?s??)?Pquali.sup(????)???O?ɥR?ܼơA???i?J?p???A???̫??i???v 
#install.packages("FactoMineR")
library(FactoMineR)
data(tea)
sample50 <- sample(nrow(tea), 50) ##??50?Ө??ժ?
tea50 <- tea[sample50,]
teanew <- tea50[ ,c("tea.time", "Tea", "How", "sugar", "sex", "age_Q", "SPC", "frequency")]
##ncp?O???G???|???X?Ӻ???, nbelements individuals?Ӽƪ????T
tea.mca<- MCA(teanew, quali.sup = c(5:7), graph = T)
summary(tea.mca, ncp = 2, nbelements = 50)
summary(tea.mca, ncp = 3, nbelements = 50)

##invisible????X?{?????ءAcex?O?Ϥ??r???j?p?Aquali.sup?N???ɥR?ܼ?(Sex)?Aind==>???ժ̡Avar==>?e?????ܼ?
##?ȥX?{???ժ̦b?s??????
plot(tea.mca, invisible = c("var","quali.sup"), cex=0.7, title = "Individuals")
##?ȥX?{?D???O??descriptions 
plot(tea.mca, invisible = c("ind","quali.sup"), cex=0.7, title = "Primary categories")
##?????ܸɥR?ܼƪ?descriptions 
plot(tea.mca, invisible = c("ind","var"), cex=0.7, title = "Supplementary categories")
##?X?{?Ҧ????O 
plot(tea.mca, invisible = c("ind"), cex=0.7, title = "All categories")
##???????X?{
plot(tea.mca, label = c("var","quali.sup"), cex=0.7, title = "Including participants")
##?z?LselectMod?ӱ????n?X?{???ܼ?descriptions 
plot(tea.mca, selectMod = c("sex","25-34","35-44","45-59","frequency","Tea"), invisible = c("ind"), cex=0.7)

##############################
###conjoint analysis##########
##############################
#install.packages("conjoint")
library(conjoint)
#smartphone <- expand.grid(CPUspeed = c("Above2GHz","Below2GHz"), Screentype = c("LCD","OLED"), Camerapixels = c("1300M","800M"), Screensize = c("5.8inch","5.2inch","4.7inch"), 
             #Flashmemory = c("4GB","2GB"), Waterproof = c("Yes","No"))
smartphone <- expand.grid(CPUspeed = c("Below2GHz","Above2GHz"), Screentype = c("LCD","OLED"), Camerapixels = c("800M","1300M"), Screensize = c("4.7inch","5.2inch","5.8inch"), 
              Flashmemory = c("2GB","4GB"), Waterproof = c("No","Yes"))
smartphone

full_design <- caFactorialDesign(data=smartphone, type="full")
print(full_design) 

part_design <- caFactorialDesign(data=smartphone, type="orthogonal")
print(part_design) 

code <- caEncodedDesign(part_design)
print(code)

level <- read.csv("level.csv", sep = ",", header = TRUE, colClasses=c("levels"="character"))
write.csv(part_design, file="factorial.csv", row.names=FALSE)
write.csv(code, file="encoded.csv", row.names=FALSE)

#############################################################
rank <- read.csv("preference1.csv", sep = ",", header = TRUE)
preference<- (nrow(code)+1 -rank)

importance <- caImportance(y=preference, x=code)
names(importance) <- names(code)
importance

caPartUtilities(y=preference, x=code, z=level) 
overall_ut <- caUtilities(y=preference, x=code, z=level) 
names(overall_ut) <- c('intercept', level[,1])
overall_ut

##visualization
(att <- apply(code,2,max) )
(attl <- unlist(sapply(1:length(att), function(x) rep(x , att[x]))) )
barplot(overall_ut[2:length(overall_ut)], col=attl,main="overall utility")

################################################################
result <- read.csv("SPSSresult.csv", sep = ",",header = TRUE)
preference <- read.csv("preference.csv", sep = ",",header = TRUE)
importance <- caImportance(y=preference, x=result)
names(importance) <- names(result)
importance

caPartUtilities(y=preference, x=result, z=level) 
overall_ut <- caUtilities(y=preference, x=result, z=level) 
names(overall_ut) <- c('intercept', level[,1])
overall_ut

##visualization
(att <- apply(result,2,max) )
(attl <- unlist(sapply(1:length(att), function(x) rep(x , att[x]))) )
barplot(overall_ut[2:length(overall_ut)], col=attl,main="overall utility")

################################################################

