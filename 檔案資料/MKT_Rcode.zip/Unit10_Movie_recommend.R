#KNN based movie recommendation rary(FNN) #KNN for regression
data<-read.csv("ratings.csv")
data<-data[,-4]
UID=1; MI=#user id
31 #?w??movie id #???Xbest favorite movies #?H?�nearest neighborstach(data)
indx=which(userId==UID)
if (length(indx)>N)  ind=sample(indx, N) #ind: movie index for assessment
if (length(indx)<=N)  ind=sample(indx, length(indx))

itemID<- movieId[ind]
itemID #?ѻPdetails for argeting moviesnowID<- which(movieId==MID) #???�r<- userId[unknowID] #?w??
ta.knn<- matrix(0, 1+length(user), 2+length(itemID))
data.knn<- data.frame(data.knn)
names(data.knn)<- c("userid", paste("unknown_item", MID), paste("item", itemID, sep= ""))
item=c(MID, itemID) #?ݵ??���=c(UID, user)
data.knn

for (i in 1:nrow(data.knn))
{
  data.temp<- data[which(data$userId == data.knn$userid[i]), ] #?Τ?????
  for (j in 1:length(item))
  {
    if ( sum( as.numeric(data.temp$movieId == item[j])) !=0 ) #?v??????
      data.knn[i, j+1]= data.temp$rating[which(data.temp$movieId==item[j])] #???L?Ĥ@?檺userid
  }
}
data.knn

data.trainX=data.knn[-1, c(-1, -2)]
data.trainY=data.knn[-1,2]
data.testX= data.knn[1, c(-1, -2)]
data.testY=data.knn[1,2]

fit.knn<- knn.reg(data.trainX, data.testX, data.trainY, k=K, algorithm= "brute") 
fit.knn #regression based KNN
list("User:"= UID, "Movie"= MID, "KNN"= K, "Actual:"= data.testY, "Regression based KNN predicted:"= fit.knn) #???X???˵??G

###CART based movie recommendation (?i?????��B?ɶ??????i?H?ٲ?)
library(rpart)
library(rpart.plot)
mr.data<-read.table("movieall.csv", header=T, sep=",") #data of movie-rating
UID=11; MID=57; N=7 #??7???w?g???��??v???ӱ��??Τ?11???v??57??????
attach(mr.data)
indx=which(userid==UID)
if (length(indx)>N)  ind=sample(indx, N) #ind: movie index for assessment
if (length(indx)<=N)  ind=sample(indx, length(indx))

itemID<- itemid[ind]
itemID #?ѻP???˪??w???v??
unknowID<- which(itemid==MID) #???ǥΤ??????LMID
user<- userid[unknowID] #?w???��????q?v???Ҧ??Τ?
user

data.cart<- matrix(0, 1+length(user), 4+length(itemID))
data.cart<- data.frame(data.cart)
names(data.cart)<- c("userid", "age", "gender", paste("unknown_item", MID), paste("item", itemID, sep= ""))
item=c(MID, itemID) #?ݵ??��ΰѻP???��??v??
data.cart$userid=c(UID, user)
data.cart

for (i in 1:nrow(data.cart))
{
  data.temp<- mr.data[which(mr.data$userid == data.cart$userid[i]), ] #?Τ?????
  data.cart[i, 2]<-data.temp$age[1]
  data.cart[i,3]<-data.temp$gender[1]
  for (j in 1:length(item))
  {
    if ( sum (as.numeric(data.temp$itemid == item[j])) !=0 ) #?v??????
      data.cart[i, j+3]= data.temp$rating[which(data.temp$itemid==item[j])]  #???Luserid?Bage?Bgender
  }
}
data.cart

names(data.cart)<- c("userid","age","gender","m0","m1","m2","m3","m4","m5","m6","m7")
data.train= data.cart[-1, c(-1)]
data.test=data.cart[1, c(-1)]
tree=m0~age+gender+m1+m2+m3+m4+m5+m6+m7 #decision tree

cart<- rpart(tree, data.train, method= "anova", minsplit=10, maxdepth=8)
cart$variable.importance
print(cart)

rpart.plot(cart,type=4,fallen.leaves = TRUE)
fit.cart=predict(cart, data.test[,-3])
list("User:"= UID, "Movie"= MID, "Method=Regression Tree", "Actual:"= data.test[1,3], " RT??s forecast:"=fit.cart) #???X?j?k?????˵??G

#############Random forest
library(randomForest)

data.rf<- matrix(0, 1+length(user), 4+length(itemID))
data.rf<- data.frame(data.rf)
names(data.rf)<- c("userid", "age", "gender", paste("unknown_item", MID), paste("item", itemID, sep= ""))
item=c(MID, itemID) #?ݵ??��ΰѻP???��??v??
data.rf$userid=c(1:nrow(data.rf))
{
  data.temp<- mr.data[which(mr.data$userid == data.cart$userid[i]), ] #?Τ?????
  data.rf[i, 2]<-data.temp$age[1]
  data.rf[i,3]<-data.temp$gender[1]
  for (j in 1:length(item))
  {
    if ( sum (as.numeric(data.temp$itemid == item[j])) !=0 ) #?v??????
      data.rf[i, j+3]= data.temp$rating[which(data.temp$itemid==item[j])]  #???Luserid?Bage?Bgender
  }
}
data.rf

names(data.rf)<- c("userid","age","gender","m0","m1","m2","m3","m4","m5","m6","m7")
data.train= data.rf[-1, c(-1)]
data.test=data.rf[1, c(-1)]

rf<-randomForest(m0~., data.train, ntree=50, mtry=6, importance=T, proximity=T, na.action=na.omit)
importance(rf)
plot(rf)

fit.rf=predict(rf, data.test[,-3])
list("User:"= UID, "Movie"= MID, "Method=Regression Tree", "Actual:"= data.test[1,3], " RF??s forecast:"= fit.rf) #???X?H???˪L???˵??G
