#install.packages("class")
#install.packages("e1071")
#install.packages("MASS")
#install.packages("klaR")
library(MASS)
library(klaR)
library(class)
library(e1071)

#################################################################
gender_size <-read.csv("gender_size.csv", stringsAsFactors = TRUE)
tune.knn<-tune.knn(gender_size[,-4], gender_size[,4], cross=3, k=c(1,3,5,7,9))
tune.knn$best.model
#k=tune.knn$best.parameters$k

knn.gender.pre<-knn(gender_size[,-4], gender_size[,-4], cl=gender_size[,4], k=tune.knn$best.parameters$k)
table(gender_size[,4], knn.gender.pre)
sum( as.numeric(knn.gender.pre == gender_size$Gender) )/ nrow(gender_size)

#############################################################
LR0<-glm(formula=Gender~., family=binomial(link="logit"), data=gender_size)
summary(LR0) #what??s the reason for insignificance

x1=list(Height= 174.8, Weight=74.6, Waist=33.5)
predict.glm(LR0, type="response", newdata=x1)

x2=list(Height= 165.6, Weight=59, Waist=27.5)
predict.glm(LR0, type="response", newdata=x2)

pre.LR0=predict.glm(LR0, type="response", newdata=gender_size)
gender_size$LRPb<-pre.LR0
result0<-ifelse (round(pre.LR0)<=0.5, "female", "male")
tab0=table(gender_size$Gender, result0)
tab0
cat("predictive accuracy", 100*sum(diag(tab0))/sum(tab0), "% \n")

#####NaiveBayes (gender)
attach(gender_size)
fit_bayes1=NaiveBayes(Gender~., gender_size)
names(fit_bayes1)
fit_bayes1$apriori
fit_bayes1$tables

pre_bayes1=predict(fit_bayes1, gender_size[,-4])
table(gender_size[,4], pre_bayes1$class)

x1=data.frame(Height= 175, Weight=74.6, Waist=33.5)
predict(fit_bayes1, x1)

x2=data.frame(Height= 166, Weight=59, Waist=27.5)
predict(fit_bayes1, x2)

#####NaiveBayes (titanic)###########################
titanic_data <-read.csv("titanic.csv", header=T, sep=",",stringsAsFactors = TRUE)
titanic<-na.exclude(titanic_data) #remove missing values
attach(titanic)

#identify the id which has missing values in age or fare
#ix<-c(which(age!=9999)& which(fare!=9999))
#titan<-titanic[id, 2:5]
#titan$survival<-titanic[id, 10] #set survival

id<-c(which(age==9999), which(fare==9999))
titan<-titanic[-id, 2:5]
titan$survival<-titanic[-id, 10] #set survival

titan[which(titan[,1]==0), 1]<-"male"  #rename 0 by male
titan[which(titan[,1]==1), 1]<-"female"  #rename 1 by female
titan[,1]=as.factor(titan$gender)

titan[which(titan[,5]==1), 5]<-"yes"
titan[which(titan[,5]==0), 5]<-"no"
titan[,5]<-as.factor(titan[,"survival"])

attach(titan)
summary(titan)
np<-sample(1:nrow(titan), round(0.3*nrow(titan)) )
tr.titan<-titan[-np,] #training
ts.titan<-titan[np,] #testing

##################################################
fit_bayes3=NaiveBayes(tr.titan[,-5], tr.titan[,5])
names(fit_bayes3)
fit_bayes3$apriori
fit_bayes3$tables

pre_bayes3=predict(fit_bayes3, ts.titan[,-5])
table(ts.titan[,5], pre_bayes3$class)

tab.NB<- table(ts.titan[,5], pre_bayes3$class)
sum(diag(tab.NB))/sum(tab.NB) #predictive accuracy
sum( as.numeric(pre_bayes3$class == ts.titan[,5]) )/ nrow(ts.titan)
tab.NB[1,1]/sum(tab.NB[1,]) #accuracy for no survival
tab.NB[2,2]/sum(tab.NB[2,]) #accuracy for yes survival

x3=data.frame(gender= "female", age=32, class="3", fare=10)
predict(fit_bayes3, x3)

x4=data.frame(gender= "female", age=32, class="1", fare=42)
predict(fit_bayes3, x4)

#######################################
#####Logistic regression using Titanic
LR<-glm(formula=survival~fare+age+class+gender, data=tr.titan, family=binomial(link="logit"), na.action=na.exclude)
summary(LR)

pre.LR= predict.glm(LR, type="response", newdata=ts.titan)
result<-ifelse (round(pre.LR)>=0.5, "yes", "no")
tab.LR<-table(ts.titan$survival, result)
tab.LR
cat("predictive accuracy", 100*sum(diag(tab.LR))/sum(tab.LR), "% \n")
tab.LR[1,1]/sum(tab.LR[1,]) #accuracy for no survival
tab.LR[2,2]/sum(tab.LR[2,]) #accuracy for yes survival

predict.glm(LR, type="response", newdata=data.frame(fare=40, age=1, class="2", gender="male"))
predict.glm(LR, type="response", newdata=data.frame(fare=40, age=40, class="2", gender="male"))

predict.glm(LR, type="response", newdata=data.frame(fare=15, age=30, class="3", gender="female"))
predict.glm(LR, type="response", newdata=data.frame(fare=50, age=30, class="1", gender="female"))

classtab<-table(class, survival)
prop.table(classtab, 1)

gendertab<-table(gender, survival)
prop.table(gendertab, 1)
