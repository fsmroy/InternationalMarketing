### Unit 1: Descriptive data analysis
data(iris)
attributes(iris)
str(iris)
summary(iris)

attach(iris)
colMeans(iris[,-5])
colMeans(iris[,1:4])

var=c(1:4)
cor(Sepal.Length, Sepal.Width)
corr=cor(iris[var], use="pairwise")
corr

cov(Petal.Length, Petal.Width)
covv=cov(iris[var], use="pairwise")
covv

#install.packages("timeDate")
library(timeDate)
skewness(iris[,1:4]) ###https://en.wikipedia.org/wiki/Skewness
kurtosis(iris[,1:4])  ###https://en.wikipedia.org/wiki/Kurtosis

#####Display various types of plots
plot(iris) #scatter matrix (???G?ϯx?})
plot(Sepal.Length, Sepal.Width) #scatter plot (???G??)
plot(Species, Sepal.Length, main="Distribution of Sepal.Length")

x=boxplot(iris[, 1:4], main="Three species") #boxplot (??????)
x$stats

y=which(iris[, 5]=="setosa")
boxplot(iris[y, 1:4], main="setosa")

colMeans(iris[1:50,1:4])
colMeans(iris[51:100,1:4])
colMeans(iris[101:150,1:4])

num_species=with(iris, c(sum(iris[,5]=="setosa"), sum(iris[,5]=="versicolor"), sum(iris[,5]=="virginica")))
barplot(num_species, names.arg=c("setosa","versicolor","virginica"), xlab="species", ylab="number") #bar chart (??????)

pie(num_species, labels= c("setosa","versicolor","virginica")) #pie chart (??????)
pie(num_species, labels=c(sum(iris[,5]=="setosa"), sum(iris[,5]=="versicolor"), sum(iris[,5]=="virginica")))

percent=round(num_species/sum(num_species)*100)
label=paste(levels(iris$Species), percent,"%")
pie(num_species, label)

plot(Sepal.Length[Species=="setosa"], Petal.Length[Species=="setosa"], pch=1, col="blue", xlim=c(3,8), ylim= c(0,9), main="scatter plot", xlab="SepalLen", ylab="PetalLen")
points(Sepal.Length[Species=="versicolor"], Petal.Length[Species=="versicolor"], pch=2, col="red")
points(Sepal.Length[Species=="virginica"], Petal.Length[Species=="virginica"], pch=3, col="green")
legend(3, 9, c("setosa","versicolor","virginica"), col=c(1,2,3), pch=c(1,2,3))

##################################################################
gender_size <-read.csv("gender_size.csv", stringsAsFactors = TRUE)
plot(gender_size) #visualization
cor(gender_size[,-4], use="pairwise")
summary(gender_size)

###outlier test based on Mahalanobis distance
gender_outlier <-read.csv("gender_outlier.csv")
attach(gender_outlier)
Male=subset(gender_outlier, Gender=="male")
Female=subset(gender_outlier, Gender=="female")

Ma.mean<-colMeans(Male[, -4])
Ma.mean
Fe.mean<-colMeans(Female[, -4])
Fe.mean

Ma.var<-cov(Male[c(1:3)], use="pairwise")
Ma.var
Fe.var<-cov(Female[c(1:3)], use="pairwise")
Fe.var

Male$mdis<- mahalanobis(Male[, -4], Ma.mean, Ma.var)
Female$mdis<-mahalanobis(Female[, -4], Fe.mean, Fe.var)

Male$maout<-(Male$mdis > qchisq(df=3, p=0.95)) #Chi-square
Female$feout<-(Female$mdis > qchisq(df=3, p=0.95)) #df: degree of freedom

attach(Male)
which(maout==TRUE)

attach(Female)
which(feout==TRUE)

###outlier test based on isolation forest
#install.packages("isotree")
library(isotree)
library(dplyr)

iso_m <- isolation.forest(Male[,-4], ntrees = 100, nthreads = -1)
pred_m <- predict(iso_m, Male[,-4])
Male[which.max(pred_m),] #Data with highest outlier score
Male[which(pred_m>0.6),]

iso_f <- isolation.forest(Female[,-4], ntrees = 100, nthreads = -1)
pred_f <- predict(iso_f, Female[,-4])
Female[which.max(pred_f),] #Data with highest outlier score
Female[which(pred_f>0.6),]

#############################
#install.packages("MASS")
#install.packages("cluster")
#install.packages("clusterSim")

library(MASS)
library(cluster)
library(clusterSim)

library(MASS)
library(cluster)
library(clusterSim)

data(iris)
#iris.nm<-data.Normalization(iris[, -5], type="n4", normalization="column")

gender_size<- read.csv("gender_size.csv")
#gender.nm<-data.Normalization(gender_size[, -4], type="n1", normalization="column")

min.nc=2
max.nc=8

#K means// K is the number of clusters
result0= kmeans(iris[,1:4], center=3)
print(result0)
result0$cluster
plot(iris)
table(iris$Species, result0$cluster)

plot(iris[,1:2], pch=result0$cluster, col=result0$cluster+1)
points(result0$centers[,1:2], col=2:4, pch=8)

plot(iris[,3:4], pch=result0$cluster, col=result0$cluster+1)
points(result0$centers[,3:4], col=2:4, pch=8)

result0$centers
##################################
KM=array(0, c(max.nc-min.nc+1, 3))
for (nc in min.nc : max.nc)
{ 
  fitkm=kmeans(iris[, -5], center=nc)
  KM[nc-(min.nc-1), 1]= fitkm$betweenss
  KM[nc-(min.nc-1), 2]= fitkm$tot.withinss
  KM[nc-(min.nc-1), 3]= index.DB(iris[,-5], fitkm$cluster, centrotypes="centroids", p=2)$DB
}
which(KM[,1]==max(KM[,1])) #the larger the better
which(KM[,2]==min(KM[,2])) #the smaller the better
which(KM[,3]==min(KM[,3])) #the smaller the better

#install.packages("NbClust")
library(NbClust)
NbClust(iris[,1:4], distance="euclidean", min.nc=2, max.nc=8, method="kmeans", index="all")

result0= kmeans(iris[,1:4], center=2)
table(iris$Species, result0$cluster)

plot(iris[,1:2], pch=result0$cluster, col=result0$cluster)
points(result0$centers[,1:2], col=1:2, pch=8)

plot(iris[,3:4], pch=result0$cluster, col=result0$cluster)
points(result0$centers[,3:4], col=1:2, pch=8)

####K medoids#############################
PM=array(0, c(max.nc-min.nc+1,2))
for (nc in min.nc : max.nc)
{ fitpm=pam(iris[,-5], nc)
PM[nc-(min.nc-1), 1]= index.DB(iris[,-5], fitpm$clustering, centrotypes="centroids", p=2)$DB
PM[nc-(min.nc-1), 2]= index.DB(iris[,-5], fitpm$clustering, dist(iris[,-5]), centrotypes="medoids", p=2)$DB
}
which(PM[,1]==min(PM[,1]))
which(PM[,2]==min(PM[,2]))

result1=pam(iris[,-5], 2)
print(result1)
result1$medoids
table(iris$Species, result1$cluster)

plot(iris[,1:2], pch=result1$cluster, col=result1$cluster)
points(result1$medoids[,1:2], col=1:2, pch=8)

plot(iris[,3:4], pch=result1$cluster, col=result1$cluster)
points(result1$medoids[,3:4], col=1:2, pch=8)