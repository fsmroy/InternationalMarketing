#####Taiwan hypermarket/supermarket/convenience store
retail = read.csv("TW_retail.csv")
retail_HM<-retail[,-c(1,3,4,10,12,19,20)]
retail_SM<-retail[,-c(1,2,4,10,12,18,20)]
retail_CS<-retail[,-c(1,2,3,10,12,18,19)]

#############MLR: multiple linear regression
table1 = array(0, c(3,2))
rownames(table1)<-c("RMSE","MAE","MAPE")
colnames(table1)<-c("MLR","MARS")

mlr.hyper<- lm(Hypermarket~., retail_HM)
summary(mlr.hyper)
#mlr.hyper$coefficients

table1[1,1] <-sqrt(mean((retail_HM$Hypermarket- mlr.hyper$fitted.values)^2))
table1[2,1] <-mean(abs(retail_HM$Hypermarket- mlr.hyper$fitted.values))
table1[3,1] <-mean(abs((retail_HM$Hypermarket- mlr.hyper$fitted.values)/retail_HM$Hypermarket))

#####################################################################
#install.packages("earth")
library(earth)
mars.hyper<-earth(Hypermarket~., degree =3, trace=2, retail_HM) #degree?Ҽ{?椬??
#summary(mars.hyper)
evimp(mars.hyper, trim=FALSE)

table1[1,2] <-sqrt(mean((retail_HM$Hypermarket - mars.hyper$fitted.values)^2))
table1[2,2] <-mean(abs(retail_HM$Hypermarket - mars.hyper$fitted.values))
table1[3,2] <-mean(abs((retail_HM$Hypermarket - mars.hyper$fitted.values)/retail_HM$Hypermarket))

table1
######visualization
plot(retail_HM[,1], type="l", col="black",ylab="hypermarket", xlab="date", main="MLR+MARS")
points(mlr.hyper$fitted.values, col="red", pch=2)
points(mars.hyper$fitted.values, col="green", pch=3)

#####################################################################
table2 = array(0, c(3,2))
rownames(table2)<-c("RMSE","MAE","MAPE")
colnames(table2)<-c("MLR","RT")
#install.packages("rpart")
library(rpart)

#############MLR: multiple linear regression
mlr.super<- lm(Supermarket~., retail_SM)
summary(mlr.super)
#mlr.super$coefficients

table2[1,1] <-sqrt(mean((retail_SM$Supermarket- mlr.super$fitted.values)^2))
table2[2,1] <-mean(abs(retail_SM$Supermarket- mlr.super$fitted.values))
table2[3,1] <-mean(abs((retail_SM$Supermarket- mlr.super$fitted.values)/retail_SM$Supermarket))

###############################################
rt.sm= rpart(Supermarket~.,retail_SM, method="anova", maxdepth=5)
print(rt.sm)
rt.sm$variable.importance
rt.sm.fit =predict(rt.sm, retail_SM)

table2[1,2] <-sqrt(mean((retail_SM$Supermarket - rt.sm.fit)^2))
table2[2,2] <-mean(abs(retail_SM$Supermarket - rt.sm.fit))
table2[3,2] <-mean(abs((retail_SM$Supermarket - rt.sm.fit)/retail_SM$Supermarket))

table2

######visualization
plot(retail_SM[,1], type="l", col="black", ylab="supermarket", xlab="date", main="MLR+RT")
points(mlr.super$fitted.values, col="red", pch=2)
points(rt.sm.fit, col="green", pch=3)

##################################################################################
table3 = array(0, c(3,2))
rownames(table3)<-c("RMSE","MAE","MAPE")
colnames(table3)<-c("MLR","KNN")

mlr.conves<- lm(Convenience_store~., retail_CS)
summary(mlr.conves)
#mlr.conves$coefficients

table3[1,1] <-sqrt(mean((retail_CS$Convenience_store - mlr.conves$fitted.values)^2))
table3[2,1] <-mean(abs(retail_CS$Convenience_store- mlr.conves$fitted.values))
table3[3,1] <-mean(abs((retail_CS$Convenience_store- mlr.conves$fitted.values)/retail_CS$Convenience_store))

######################################################################
#install.packages("FNN")
library(FNN)
knn.conves<- knn.reg(retail_CS[,-1], retail_CS[,-1], retail_CS[,1], k=2, algorithm= "brute")

table3[1,2] <-sqrt(mean((retail_CS$Convenience_store - knn.conves$pred)^2))
table3[2,2] <-mean(abs(retail_CS$Convenience_store - knn.conves$pred))
table3[3,2] <-mean(abs((retail_CS$Convenience_store - knn.conves$pred)/retail_CS$Convenience_store))

table3

######visualization
plot(retail_CS[,1], type="l", col="black", ylab="convenience store", xlab="date", main="MLR+KNN")
points(mlr.conves$fitted.values, col="red", pch=2)
points(knn.conves$pred, col="green", pch=3)
